package com.tcs.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.model.*;
import com.tcs.repository.BookRepository;
import com.tcs.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BookRepository bookRepository;
	
	@Override
	public void addUser(User user) 
	{
		userRepository.addUser(user);
		
	}

	@Override
	public List<User> retrieveAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.retrieveAllUsers();
	}

	@Override
	public void issueBook(String uid, String bid) 
	{
		int userId=Integer.parseInt(uid);
		int bookId=Integer.parseInt(bid);
		userRepository.updateUser(userId, bookId);
		bookRepository.updateUser(userId, bookId);
		
	}

	@Override
	public User getUser(int uid) {
		return userRepository.getUser(uid);
	}

}
