package com.tcs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.model.Book;
import com.tcs.model.User;
import com.tcs.repository.BookRepository;
import com.tcs.repository.UserRepository;

@Service
public class BookServiceImpl implements BookService 
{
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired 
	private UserRepository userRepository;
	
	public void addBook(Book book) {
		bookRepository.addBook(book);

	}

	@Override
	public List<Book> retrieveAllBooks() {
		return bookRepository.retrieveAllBooks();
		 
	}

	@Override
	public Book getBook(int bid) {
		
		return bookRepository.getBook(bid);
	}

	@Override
	public String returnBook(int bid) {
		Book book = bookRepository.getBook(bid);
		int uid = book.getUid();
		User user = userRepository.getUser(uid);
		String userName=user.getUsername();
		bookRepository.updateUser(bid);
		userRepository.updateUser(uid);
		
		return userName;
	}

}
