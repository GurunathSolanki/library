package com.tcs.service;
import java.util.List;

import com.tcs.model.Book;
public interface BookService 
{
	public void addBook(Book book);
	public List<Book> retrieveAllBooks();
	public Book getBook(int bid);
	public String returnBook(int bid);

}
