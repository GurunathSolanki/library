package com.tcs.service;
import java.util.List;

import com.tcs.model.*; 
public interface UserService 
{
	public void addUser(User user);
	public List<User> retrieveAllUsers(); 
	public void issueBook(String uid , String bid);
	public User getUser(int uid);
}
