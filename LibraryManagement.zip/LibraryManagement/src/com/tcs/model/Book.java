package com.tcs.model;

//import org.hibernate.annotations.*;
import javax.persistence.*;



@Entity

@Table(name="book")
public class Book 
{
	private int Bid , Uid;
	private String bookname;
	
	@Id
	@GeneratedValue
	@Column(name="bid")
	public int getBid() {
		return Bid;
	}
	public void setBid(int bid) {
		Bid = bid;
	}
	
	@Column(name="uid")
	public int getUid() {
		return Uid;
	}
	public void setUid(int uid) {
		Uid = uid;
	}
	
	@Column(name="bookname")
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	
	
	

}
