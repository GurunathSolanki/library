package com.tcs.model;
import javax.persistence.*;

@Entity
@Table (name="user")
public class User 
{
	// TODO - Variable names CamelCase
	private int Uid , Bid;
	
	@Id
    @GeneratedValue
	@Column(name="uid")
	public int getUid() {
		return Uid;
	}

	public void setUid(int uid) {
		Uid = uid;
	}

	@Column(name="bid")
	public int getBid() {
		return Bid;
	}

	public void setBid(int bid) {
		Bid = bid;
	}

	private String username;
	
	@Column(name="username")
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	// TODO - A User can issue 3 books 
	// TOOD - A book is issued to One User
}
