package com.tcs.controller;

public class UserController {
	
	private void add() {
		// TODO Auto-generated method stub

	}
	
	private void delete() {
		// TODO Auto-generated method stub

	}
	
	private void update() {
		// TODO Auto-generated method stub

	}
	
	private void show() {
		// TODO Auto-generated method stub

	}

}
