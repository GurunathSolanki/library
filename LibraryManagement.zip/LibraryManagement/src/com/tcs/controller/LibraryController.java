package com.tcs.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import com.tcs.model.*;
import com.tcs.service.*;

@Controller
public class LibraryController 
{
	@Autowired
	private UserService userService;
	
	@Autowired
	private BookService bookService;
	
	@RequestMapping
	public void addUser(@ModelAttribute("user")User user)
	{
		userService.addUser(user);
	}
	
	// TODO - Request should be Post
	// TODO - Book and User should have Seperate Controller as the Responsibilities are different
	@RequestMapping
	public void addBook(@ModelAttribute("book")Book book)
	{
		bookService.addBook(book);
	}
	
	@RequestMapping
	public void checkAvailibility(ModelMap map)
	{
		map.put("bookList", bookService.retrieveAllBooks());
	}
	
	@RequestMapping
	public void selectUser(@RequestParam("bookToBeIssuedId")String booToBeIssuedId,HttpSession session,ModelMap map)
	{
		session.setAttribute("bookToBeIssuedId", booToBeIssuedId);
		session.setAttribute("bookNameToBeIssued", bookService.getBook(Integer.parseInt(booToBeIssuedId)).getBookname());
		map.put("userList", userService.retrieveAllUsers());
	}
	
	@RequestMapping
	public void issueBook(@RequestParam("userGettingBookId")String userGettingBookId,HttpSession session)
	{
		session.setAttribute("userGettingBookId", userGettingBookId);
		session.setAttribute("userNameGettingBook", userService.getUser(Integer.parseInt(userGettingBookId)).getUsername());
		userService.issueBook((String)session.getAttribute("userGettingBookId"), (String)session.getAttribute("bookToBeIssuedId"));
	}
	
	@RequestMapping
	public void issuedBooks(ModelMap map)
	{
		map.put("bookList", bookService.retrieveAllBooks());
	}
	
	@RequestMapping
	public void returnBook(@RequestParam("bookToBeReturnedId")String bookToBeReturnedId,HttpSession session)
	{
		String UserReturningBook=bookService.returnBook(Integer.parseInt(bookToBeReturnedId));
		session.setAttribute("returnedBookName", bookService.getBook(Integer.parseInt(bookToBeReturnedId)).getBookname());
		session.setAttribute("userNameReturningBook", UserReturningBook);
	}

}
