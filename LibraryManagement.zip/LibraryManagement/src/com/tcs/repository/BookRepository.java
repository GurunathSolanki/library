package com.tcs.repository;

import java.util.List;

import com.tcs.model.Book;

public interface BookRepository {

	public void addBook(Book book);
	public List<Book> retrieveAllBooks();
	public void updateUser(int uid,int bid);
	public void updateUser(int bid);
	public Book getBook(int bid);
}
