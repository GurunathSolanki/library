package com.tcs.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.tcs.model.Book;

@Repository
public class BookRepositoryImpl implements BookRepository {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void addBook(Book book) {
		hibernateTemplate.save(book);

	}

	@Override
	public List<Book> retrieveAllBooks() 
	{
		List<Book> bookList;
		bookList=hibernateTemplate.loadAll(Book.class);
		return bookList;
	}

	@Override
	public void updateUser(int uid, int bid) {
		Book book = hibernateTemplate.get(Book.class, bid);
		book.setUid(uid);
		hibernateTemplate.saveOrUpdate(book);
	}

	@Override
	public Book getBook(int bid) {
		
		return hibernateTemplate.get(Book.class, bid);
	}

	@Override
	public void updateUser(int bid) {
		Book book=hibernateTemplate.get(Book.class, bid);
		book.setUid(0);
		hibernateTemplate.saveOrUpdate(book);
		
	}
	
	

}
