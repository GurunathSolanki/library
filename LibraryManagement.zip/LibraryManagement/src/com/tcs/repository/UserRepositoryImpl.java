package com.tcs.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.tcs.model.*;

@Repository
public class UserRepositoryImpl implements UserRepository {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Override
	public void addUser(User user) {
		hibernateTemplate.save(user);
	}

	@Override
	public List<User> retrieveAllUsers() {
		// TODO Auto-generated method stub
		return hibernateTemplate.loadAll(User.class);
	}

	@Override
	public void updateUser(int uid, int bid) {
		User user = hibernateTemplate.get(User.class, uid);
		user.setBid(bid);
		hibernateTemplate.saveOrUpdate(user);

	}

	@Override
	public User getUser(int uid) {
		return hibernateTemplate.get(User.class, uid);
	}

	@Override
	public void updateUser(int uid) {
		User user = hibernateTemplate.get(User.class, uid);
		user.setBid(0);
		hibernateTemplate.saveOrUpdate(user);
		
	}

}
