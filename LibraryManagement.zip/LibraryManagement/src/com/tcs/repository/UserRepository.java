package com.tcs.repository;

import java.util.List;

import com.tcs.model.*;
public interface UserRepository 
{
	public void addUser(User user);
	public List<User> retrieveAllUsers();
	public void updateUser(int uid,int bid);
	public void updateUser(int uid);
	public User getUser(int uid);
}
